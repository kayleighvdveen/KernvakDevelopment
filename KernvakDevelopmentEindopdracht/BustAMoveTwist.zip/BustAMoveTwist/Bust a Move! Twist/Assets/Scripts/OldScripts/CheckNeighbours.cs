﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace BustAMove { 
    public class CheckNeighbours : MonoBehaviour {
        
        Color bubbleColor;
        int xPos, yPos;

        void DestroyMatches() {
          /*foreach () {
                // destroy matched
            }*/
            // destroy self
        }

        void FindMatches() {
            // 2D array - x Position & y Position
            // if bubble color = other bubble color & length > 2
        }
           
    }
}
