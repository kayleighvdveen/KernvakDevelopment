﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Panda;

namespace AIEnemies {
    public class WayPoints : MonoBehaviour {

        [HideInInspector] public bool path;

        // Make waypoints
        public Transform[] waypoints {
            get {
                var wp = new List<Transform>();
                foreach (Transform c in this.transform) {
                    wp.Add(c);
                }
                return wp.ToArray();
            }
        }

        // Draw lines and spheres
        public void OnDrawGizmos() {
            DrawLines();
            DrawPoints(0.05f);
        }

        public void OnDrawGizmosSelected() {
            Gizmos.color = Color.white;
            DrawLines();
            DrawPoints(0.5f);
        }

        // Draw points in scene viewer
        public void DrawPoints(float r) {
            var wp = waypoints;

            for (int i = 0; i < waypoints.Length; i++) {
                Gizmos.DrawSphere(wp[i].position, r);
            }
        }

        // Draw path lines in scene viewer
        public void DrawLines() {
            var wp = waypoints;

            for (int i = 1; i < waypoints.Length; i++) {
                var p0 = wp[i - 1].position;
                var p1 = wp[i - 0].position;
                Gizmos.DrawLine(p0, p1);
            }

            if (path && wp.Length > 1 ) {
                var p0 = wp[0].position;
                var p1 = wp[wp.Length - 1].position;
                Gizmos.DrawLine(p0, p1);
            }
        }
    }
}
