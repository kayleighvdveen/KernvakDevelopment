﻿using UnityEngine;
using System.Collections;
using Panda;

namespace AIEnemies {
    public class EnemyWP : MonoBehaviour {

        public WayPoints waypoints;
        private AIUnit self;
        private int wpIndex;

        // Initialization
        private void Start() {
            wpIndex = 0;
            self = GetComponent<AIUnit>();
        }

        [Task]
        bool NextWaypoint() {
            if (waypoints != null) {
                wpIndex++;

                if (Task.isInspected)
                    Task.current.debugInfo = string.Format("i={0}", waypointArrayIndex);
            }
            return true;
        }

        [Task]
        bool SetDestination_Waypoint() {
            bool isSet = false;

            if (waypoints != null) {
                var i = waypointArrayIndex;
                var p = waypoints.waypoints[i].position;
                isSet = self.SetDestination(p);
            }
            return isSet;
        }

        [Task]
        public bool SetDestination_Waypoint(int i) {
            bool isSet = false;

            if (waypoints != null) {
                var p = waypoints.waypoints[i].position;
                isSet = self.SetDestination(p);
            }
            return isSet;
        }

        [Task]
        public void MoveTo(int i) {
            SetDestination_Waypoint(i);
            self.MoveTo_Destination();
            self.WaitArrival();
        }

        [Task]
        public void LookAt(int i) {
            self.SetTarget(waypoints.waypoints[i].transform.position);
            self.AimAt_Target();
        }


        int waypointArrayIndex {
            get {
                int i = 0;
                if (waypoints.path) {
                    i = wpIndex % waypoints.waypoints.Length;
                } else {
                    int n = waypoints.waypoints.Length;
                    i = wpIndex % (n * 2);

                    if( i > n - 1 )
                        i = (n - 1) - (i % n); 
                }
                return i;
            }
        }
    }
}
