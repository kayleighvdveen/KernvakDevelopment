﻿using UnityEngine;
using System.Collections;
using Panda;

namespace AIEnemies {
    public class AIDeath : MonoBehaviour {

        public float duration = 1.5f;
        private float startTime;

        // Initialization
        private void Start() {
            startTime = Time.time;
        }

        // Update is called once per frame
        private void Update() {
            if( Time.time - startTime > duration ) {
                Destroy(this.gameObject);
            }
        }
    }
}
