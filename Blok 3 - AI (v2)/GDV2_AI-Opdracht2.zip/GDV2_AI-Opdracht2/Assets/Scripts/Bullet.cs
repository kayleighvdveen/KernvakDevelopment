﻿using UnityEngine;
using System.Collections;

namespace AIEnemies {
    public class Bullet : MonoBehaviour {

        public GameObject shooter;
        public float speed = 1.0f;
        public float duration = 5.0f;
        public float damage = 1.0f;
        private float startTime;

        // Initialization
        private void Start() {
            startTime = Time.time;
        }

        // Either destroys the bullet or checks if it was hit
        private void FixedUpdate() {
            Vector3 velocity = this.transform.forward * speed;
            this.transform.position = this.transform.position + velocity * Time.deltaTime;

            if (Time.time - startTime > duration)
                Destroy(this.gameObject);
            else
                BulletScan();   
        }

        // Checks if bullet actually hit the target
        public void BulletScan() {
            RaycastHit hit;
            var ray = new Ray(this.transform.position, this.transform.forward);

            if (Physics.Raycast(ray, out hit, 1.0f)) {
                var other = hit.collider;
                var type = other.gameObject.GetComponent<TriggerType>();
                var go = other.attachedRigidbody != null ? other.attachedRigidbody.gameObject : other.gameObject;

                if (type != null && type.collidesWithBullet && go != shooter) {
                    AIUnit target = go.GetComponent<AIUnit>();
                    OnHit(target);
                    Explode(hit);
                }
            }
        }

        // Damage on hit
        public void OnHit(AIUnit target) {
            if (target != null && target != shooter) {
                if (this.shooter != null) {
                    var shotBy = this.shooter.GetComponent<AIUnit>();
                    target.shotBy = shotBy;
                    target.lastShotTime = Time.time;

                    if (shotBy != null) {
                        shotBy.lastHit = target;
                        shotBy.lastHitTime = Time.time;
                    }
                }
                target.health -= damage;
            }
        }
       
        // Destroy the bullet on hit
        public void Explode(RaycastHit hit) {
            var pos = this.transform.position;
            var dir = this.transform.forward;

            Destroy(this.gameObject);

            // Compute reflection direction
            dir = dir -2.0f * hit.normal * (Vector3.Dot(dir, hit.normal));
        }
    }
}

