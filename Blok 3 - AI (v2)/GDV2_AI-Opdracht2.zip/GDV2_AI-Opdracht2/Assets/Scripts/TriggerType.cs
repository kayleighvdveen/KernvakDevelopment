﻿using UnityEngine;
using System.Collections;
using Panda;

namespace AIEnemies {
    public class TriggerType : MonoBehaviour {
        
        // Checks if objects collides with bullet / vision
        public bool collidesWithBullet = false;
        public bool collidesWithVision = false;
    }

}
