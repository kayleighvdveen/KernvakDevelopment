<?php

	// Variables
	$server_mainname = $_POST["serverMainName"];
	$server_username = $_POST["serverUsername"];
	$server_password = $_POST["serverPassword"];
	$server_database = $_POST["serverDatabase"];
		
	// Connection to the mySQL server
	$connection = new mysqli($server_mainname, $server_username, $server_password, $server_database);

	if($connection) {
		// Variables for userdatabase
		$identity = $_POST["update_identity"];
		$username = $_POST["update_username"];
		$password = $_POST["update_password"];
		$email = $_POST["update_email"];
		$firstname = $_POST["update_firstname"];
		$lastname = $_POST["update_lastname"];
		$gender = $_POST["update_gender"];
		$age = $_POST["update_age"];

		// Getting data from the database
		$sqlCheck = "SELECT identity FROM userinfo WHERE identity = '".$identity."' ";
		$resultCheck = mysqli_query($connection, $sqlCheck);
			
		if($resultCheck) {
			if(mysqli_num_rows($resultCheck) > 0) {
				// Insert data to the database					
				$sqlUpdate = "UPDATE userinfo SET 
					username = '".$username."', 
					password = '".$password."', 
					email = '".$email."', 
					firstname = '".$firstname."', 
					lastname = '".$lastname."', 
					gender = '".$gender."', 
					age = '".$age."'
					WHERE identity = '".$identity."' ";
					
				$resultUpdate = mysqli_query($connection, $sqlUpdate);
					
				if($resultUpdate) {
					echo("Success");
				}
					
				else {
					echo("Failed");
				}
			}
				
			else {
				echo("Unknown");
			}
		}
			
		else {
			echo("Failed");
		}
	}
		
	else {
		//die("Coonection Failed.".mysql_connect_error());
		echo("Connect Error");
	}
?>