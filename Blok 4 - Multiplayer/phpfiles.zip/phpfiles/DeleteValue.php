<?php

	// Variables
	$server_mainname = $_POST["serverMainName"];
	$server_username = $_POST["serverUsername"];
	$server_password = $_POST["serverPassword"];
	$server_database = $_POST["serverDatabase"];
		
	// Connection to the mySQL server
	$connection = new mysqli($server_mainname, $server_username, $server_password, $server_database);

	if($connection) {
		// Variables for userdatabase
		$identity = $_POST["delete_identity"];

		// Getting data from the database
		$sqlCheck = "SELECT identity FROM userinfo WHERE identity = '".$identity."' ";
		$resultCheck = mysqli_query($connection, $sqlCheck);
			
		if($resultCheck) {
			$sqlDelete = "DELETE FROM `userinfo` WHERE identity = '".$identity."' ";
			$resultDelete = mysqli_query($connection, $sqlDelete);
			
			if($resultDelete) {
				echo("Success");
			}
			
			else {
				echo("Failed!");
			}
		}
			
		else {
			echo("Failed");
		}
	}
		
	else {
		//die("Coonection Failed.".mysql_connect_error());
		echo("Connect Error");
	}
?>