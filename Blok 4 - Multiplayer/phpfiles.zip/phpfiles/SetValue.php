<?php

	// Variables
	$server_mainname = $_POST["serverMainName"];
	$server_username = $_POST["serverUsername"];
	$server_password = $_POST["serverPassword"];
	$server_database = $_POST["serverDatabase"];
		
	// Connection to the mySQL server
	$connection = new mysqli($server_mainname, $server_username, $server_password, $server_database);

	if($connection) {
		// Variables for userdatabase
		$username = $_POST["set_username"];
		$password = $_POST["set_password"];
		$email = $_POST["set_email"];
		$firstname = $_POST["set_firstname"];
		$lastname = $_POST["set_lastname"];
		$gender = $_POST["set_gender"];
		$age = $_POST["set_age"];
		
		// Getting data from the database
		$sqlCheck = "SELECT identity FROM userinfo WHERE username = '".$username."' ";
		$resultCheck = mysqli_query($connection, $sqlCheck);
			
		if($resultCheck) 	{
			if(mysqli_num_rows($resultCheck) < 1) {
				// Insert data to the database
				$sqlSet = "INSERT INTO userinfo (username, password, email, firstname, lastname, gender, age)
						VALUES('".$username."','".$password."','".$email."','".$firstname."','".$lastname."','".$gender."','".$age."')";
				$resultSet = mysqli_query($connection, $sqlSet);
					
				if($resultSet) {
					echo("Success");
				}
					
				else {
					echo("Failed");
				}
			}
				
			else {
				echo("Existed");
			}
		}
			
		else {
			echo("Failed");
		}
	}
	
	else {
		//die("Coonection Failed.".mysql_connect_error());
		echo("Connect Error");
	}
?>