<?php

	// Security check on server
	$serverKeycode = "HashCode123";

	// Check and assign the method to execute on server
	$methodName = $_POST['methodName'];

	if($serverKeycode == $_POST['serverKeycode']) {
		if($methodName == "SetValue") {
			include 'account/SetValue.php';
		}

		else if($methodName == "CheckValue") {
			include 'account/CheckValue.php';
		}

		else if($methodName == "ListValue") {
			include 'account/ListValue.php';
		}

		else if($methodName == "UpdateValue") {
			include 'account/UpdateValue.php';
		}

		else if($methodName == "DeleteValue") {
			include 'account/DeleteValue.php';
		}

		else if($methodName == "GetValue") {
			include 'account/GetValue.php';
		}

		else {
			echo ("Error");
		}
	}

	else {
		echo ("Error");
	}
?>